/** Automatically generated file. DO NOT MODIFY */
package catcake_application.model_catcake;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}